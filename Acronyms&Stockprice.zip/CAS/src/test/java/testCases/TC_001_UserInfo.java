package testCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilityFiles.ScreenShots;

public class TC_001_UserInfo extends BaseClass {
	
	
	// method to get the name,email info and the screenshot
	@Test(priority = 1)
	public void verifyInfo() throws InterruptedException {
		HomePage hp = new HomePage(driver);
		hp.openProfileInfo();
		
		String name = driver.findElement(By.xpath("//*[@id=\"mectrl_currentAccount_primary\"]")).getText();
		System.out.println(name);
		
		String email = driver.findElement(By.xpath("//*[@id=\"mectrl_currentAccount_secondary\"]")).getText();
		System.out.println(email);
		
		ScreenShots sc = new ScreenShots();
		try {
			sc.screenshot("profile.png");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
