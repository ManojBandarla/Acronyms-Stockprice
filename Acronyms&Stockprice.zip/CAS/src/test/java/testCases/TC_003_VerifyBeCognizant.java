package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Acronyms;

public class TC_003_VerifyBeCognizant extends TC_002_Verify {
	
	// method to verify it is cognizant page or not
	@Test(priority = 4)
	public void backAndVerifyBeCognizant() throws InterruptedException {
		Acronyms a = new Acronyms(driver);
		a.navigateBack();
		
		String act_title = driver.getTitle();
		System.out.println("the actual title: "+act_title);
		String exp_title = "Be.Cognizant - Home";
		Assert.assertEquals(act_title, exp_title);
	}
}
