package testCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.GoogleStockPrice;
import pageObjects.HomePage;

public class TC_004_Get_NASDAQ extends TC_003_VerifyBeCognizant {
	
	public static double cogprice;
	public static double gogprice;
	
	// scrolling the page
	@Test(priority = 5)
	public void Scroll() throws InterruptedException {
		HomePage h = new HomePage(driver);
		h.scrolldown();
		Thread.sleep(2000);
		
		
		HomePage hp = new HomePage(driver);
		driver.findElement(By.xpath("//span[normalize-space()='Announcements']")).click();
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
		hp.scrolldown();
		Thread.sleep(2000);
	}
	
	// get the stock price from cognizant site
	@Test(priority = 6)
	public void price() throws InterruptedException {
		String stprice = driver.findElement(By.xpath("(//div[@class='stockValue_60e60a8c'])[1]")).getText();
		Thread.sleep(1000);
		cogprice = Double.parseDouble(stprice);
		System.out.println(cogprice);
		
	}
	
	// get the stock price from google
	@Test(priority = 7)
	public void googlePrice() throws InterruptedException, IOException {
		GoogleStockPrice gg = new GoogleStockPrice(driver);
		gg.openGoogleStock();
		String stp = driver.findElement(By.xpath("//span[@class='IsqQVc NprOob wT3VGc']")).getText();
		Thread.sleep(2000);
		gogprice = Double.parseDouble(stp);
		System.out.println(gogprice);
	}
	
	
	// method for comparing the cognizant and google stock price
	@Test(priority = 8)
	public void compare() {
		if(cogprice == gogprice) {
			System.out.println("Validation: PASSED");
//			Assert.assertTrue(true);
		}
		else {
			System.out.println("Validation: FAILED");
		}
	}	
}
