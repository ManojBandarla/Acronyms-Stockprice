package testCases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Acronyms;
import pageObjects.HomePage;
import utilityFiles.ScreenShots;

public class TC_002_Verify extends TC_001_UserInfo {
	
	// method for acronym page verification
	@Test(priority = 2)
	public void verify() throws InterruptedException, IOException {
		Acronyms ac = new Acronyms(driver);
		ac.verify();
		Thread.sleep(4000);
		

		String exp_title = "Acronyms";
		System.out.println("the expected title: "+exp_title);
		String act_title = driver.getTitle();
		System.out.println("the actual title: "+act_title);
		Assert.assertEquals(exp_title,act_title);
	}
	
	// method to get the acronyms name and store the details in excel sheet
	public void getAcronyms() throws IOException, InterruptedException {
		
		Thread.sleep(3000);
        List<WebElement> acronyms = driver.findElements(By.xpath("//tbody/tr/td[1]"));
        Thread.sleep(3000);
        System.out.println(acronyms.size());
    	for(int i=0;i<acronyms.size();i++) {
    		System.out.println(acronyms.get(i).getText());
//    		Thread.sleep(1000);
    	
    		String data = acronyms.get(i).getText();
    	    String file = System.getProperty("user.dir")+"\\testData\\data@CAS.xlsx";
//    	    Thread.sleep(3000);
    	    utilityFiles.ExcelUtils.setCellData(file, "Sheet2", i, 1, data);
    	}
    	
    	ScreenShots sc = new ScreenShots();
    	HomePage h = new HomePage(driver);
    	
    	driver.findElement(By.xpath("//div[@class='ei_u_9f38462c ei_w_9f38462c gz_w_9f38462c']")).click();
    	Thread.sleep(1000);
    	
    	for(int j=0;j<8;j++) {
    		
    	for(int k=0;k<5;k++) {
    		h.scrolldown();   		
    	}
    	Thread.sleep(1000);
    	sc.screenshot("Screen"+j+".png");
    	}
	}
}