package utilityFiles;
 
import java.io.File;
import java.io.IOException;
import testBase.BaseClass;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
 
public class ScreenShots extends BaseClass{
	public void screenshot(String scName) throws IOException{
    	TakesScreenshot ts = (TakesScreenshot)driver;
    	File src = ts.getScreenshotAs(OutputType.FILE);
    	File trg = new File("C:\\Users\\2323698\\OneDrive - Cognizant\\Desktop\\Cas\\CAS\\screenshots\\"+scName);
    	FileUtils.copyFile(src,trg);
    }
}


