package testBase;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;

public class BaseClass {
	public static WebDriver driver;
	
	@BeforeClass
	@Parameters({"browser"})
	
	// method for choosing the browser option
	public void setup(String br) {
		if(br.equals("chrome")) {
		driver = new ChromeDriver();
		}
		else if(br.equals("edge")) {
			driver = new EdgeDriver();
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://cognizantonline.sharepoint.com/sites/Be.Cognizant/SitePages/Home.aspx");
		driver.manage().window().maximize();
	}
	
	// method for closing all the browsers
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
