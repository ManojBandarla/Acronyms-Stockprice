package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.opentelemetry.sdk.logs.data.Body;

public class HomePage extends BasePage {

	// constructor
	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	// locators
	By profile_logo = By.xpath("//*[@id=\"O365_MainLink_MePhoto\"]/div/div/div/div/div[2]");
	
	
	// Action methods
	// method for opening the profile
	public void openProfileInfo() throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(profile_logo).click();
		Thread.sleep(4000);
		driver.findElement(profile_logo).click();
		Thread.sleep(5000);
	}
	
	// method for scrolling the page
	public void scrolldown() throws InterruptedException {
		
		
//		WebElement el = driver.findElement(By.xpath("//div[@class='ms-Stack custom-footer-content justify-center justify-left-tablets-or-above css-187']"));
//		Actions act = new Actions(driver);
//		act.sendKeys(el, Keys.END).perform();
//		Thread.sleep(2000);
		
		
//		JavascriptExecutor js = (JavascriptExecutor)driver;   	
//    	WebElement end = driver.findElement(By.xpath("//h3[normalize-space()='NASDAQ']"));
//    	js.executeScript("arguments[0].scrollIntoView();",end);
		
		
		Actions act = new Actions(driver);
//		List<WebElement> list = driver.findElements(By.tagName("body"));
//		WebElement body = list.get(0);

		
		int j=0;
		while(j!=6) {
		act.sendKeys(Keys.ARROW_DOWN).perform();
		j++;
		}

	}
}
