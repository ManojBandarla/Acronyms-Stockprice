package pageObjects;

import org.openqa.selenium.WebDriver;

// base page initialize the driver
public class BasePage {
	WebDriver driver;
	public BasePage(WebDriver driver) {
		this.driver = driver;
	}
}
