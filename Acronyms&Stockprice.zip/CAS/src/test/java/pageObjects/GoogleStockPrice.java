package pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.github.dockerjava.api.model.Driver;

public class GoogleStockPrice extends BasePage {
	
	//constructor
	public GoogleStockPrice(WebDriver driver) {
		super(driver);
	}
	
	
	//locators
	By textArea = By.xpath("//textarea[@id='APjFqb']");
	
	//Action methods
	// method for getting the stock value from google
	public void openGoogleStock() throws InterruptedException, IOException {
		driver.get("https://www.google.com/");
		String file = System.getProperty("user.dir")+"\\testData\\data@CAS.xlsx";
		String input = utilityFiles.ExcelUtils.getCellData(file,"Sheet1", 0, 0);
		driver.findElement(textArea).sendKeys(input);
		Actions act = new Actions(driver);
		act.sendKeys(Keys.ENTER).perform();
		Thread.sleep(2000);
	}

}
