# Selenium Automation Testing Project: Acronyms and Cognizant Stock Price
 
## Project Overview
 
This Selenium automation testing project focuses on automating tasks related to the Be.Cognizant portal. The primary objectives include capturing user information, navigating through the portal, verifying the presence of specific elements, and comparing stock prices. The project uses various dependencies and libraries to facilitate automation.
 
## Project Structure
 
### 1. Maven Repository
 
- **Maven Version**: 3.12.1
 
### 2. Dependencies
 
- **Apache POI**
 - Version: 5.2.4
 - Purpose: Used for reading and writing Excel files, facilitating data-driven testing.
 
- **TestNG**
 - Version: 7.9.0
 - Purpose: Framework for test automation that allows for parallel execution and flexible test configuration.
 
- **Extent Report**
 - Version: 5.1.1
 - Purpose: Generates interactive and detailed HTML reports to enhance test result analysis.
 
- **Selenium**
 - Version: 4.16.1
 - Purpose: Enables interaction with web elements, navigation, and form submission in the browser.
 
## Automation Test Flow
 
1. **Open Be.Cognizant Page**
 - Navigate to the Be.Cognizant portal.
 
2. **Capture User Info**
 - Click on the profile.
 - Capture user information.
 - Print and take screenshots.
 
3. **Navigate to Company Tab**
 - Click on the Company tab.
 
4. **Verify and Navigate to Acronym Page**
 - Verify the presence of "Acronym."
 - Click on "Acronym."
 - Verify navigation to the correct Acronym page.
 
5. **Capture Acronyms and Screenshots**
 - Scroll down.
 - Print all given acronyms.
 - Take screenshots for each acronym.
 
6. **Navigate Back to Be.Cognizant Page**
 - Navigate back.
 - Verify return to Be.Cognizant page.
 
7. **Capture Cognizant Stock Price**
 - Scroll down.
 - Capture the Cognizant stock price.
 
8. **Verify NASDAQ and CTSH Display**
 - Verify the display of "NASDAQ" and "CTSH."
 
9. **Google Search for Cognizant Stock Price**
 - Open Google.
 - Search for "Cognizant Stock Price."
 
10. **Capture Google Stock Price**
 - Capture the stock price from Google.
 
11. **Compare Stock Prices**
 - Compare Cognizant stock price from the portal with the one from Google.
 
12. **Compare with Past Data**
 - Compare the current stock price with historical data to check for consistency.
 
## How to Run the Tests
 
1. **Open Eclipse IDE:**
 - Launch Eclipse IDE on your machine.
 
2. **Import Project:**
 - Select `File` -> `Import` from the menu.
 - Choose `Existing Maven Projects` and click `Next`.
 - Browse to the directory where you cloned the repository and select the project.
 
3. **Update Maven Project:**
 - Right-click on the project in the Project Explorer.
 - Choose `Maven` -> `Update Project`.
 - Click `OK` to update dependencies.

4. **Set Up Configuration**
 - Open the 'src/test/resources/config.properties' file.
 - Update any configuration parameters like browser type, URLs, etc., as needed.
 
5. **Run Test Suite:**
 - Locate the test suite file (e.g., `src/test/java/TestSuite.java`).
 - Right-click on the file and choose `Run As` -> `TestNG Suite`.
 
6. **View Reports:**
 - After execution, open the `test-output` folder.
 - Find the Extent Report HTML file (`index.html`) for detailed test reports.
 
## Author Information
 
- **Manoj Bandarla**
- **Anusha Chinnala**
- **Adithya gaikwad**
 
## Disclaimer
 
This project is intended for educational and testing purposes only. The authors are not responsible for any unauthorized use or modification of the code. Use at your own risk.